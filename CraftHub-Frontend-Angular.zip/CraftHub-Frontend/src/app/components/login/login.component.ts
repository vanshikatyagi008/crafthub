import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { LoginRequest } from '../../models/user.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  model: LoginRequest = { email: '', password: '' };
  loading = false;
  error = '';

  constructor(
    private auth: AuthService,
    private cart: CartService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  submit(): void {
    this.loading = true;
    this.error = '';

    this.auth.login(this.model).subscribe({
      next: () => {
        this.cart.loadCart().subscribe({ error: () => {} });
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
        this.router.navigateByUrl(returnUrl);
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error?.message || 'Invalid email or password.';
      }
    });
  }
}
