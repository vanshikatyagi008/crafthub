import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {
  loading = true;
  error = '';

  constructor(public cart: CartService, public auth: AuthService) {}

  ngOnInit(): void {
    if (!this.auth.isLoggedIn()) {
      this.loading = false;
      return;
    }
    this.cart.loadCart().subscribe({
      next: () => (this.loading = false),
      error: () => {
        this.loading = false;
        this.error = 'Could not load your cart.';
      }
    });
  }

  updateQuantity(cartItemId: number, quantity: number): void {
    if (quantity < 1) return;
    this.cart.updateQuantity(cartItemId, quantity).subscribe();
  }

  remove(cartItemId: number): void {
    this.cart.removeItem(cartItemId).subscribe();
  }
}
