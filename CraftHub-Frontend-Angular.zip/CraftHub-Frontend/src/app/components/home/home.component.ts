import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CategoryService } from '../../services/category.service';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { Category } from '../../models/category.model';
import { Product } from '../../models/product.model';
import { ProductCardComponent } from '../product-card/product-card.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, ProductCardComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  categories: Category[] = [];
  featuredProducts: Product[] = [];
  loading = true;
  error = '';

  constructor(
    private categoryService: CategoryService,
    private productService: ProductService,
    public cartService: CartService
  ) {}

  ngOnInit(): void {
    this.categoryService.getAll().subscribe({
      next: (categories) => (this.categories = categories),
      error: () => (this.error = 'Could not load categories. Is the API running?')
    });

    this.productService.getFeatured().subscribe({
      next: (products) => {
        this.featuredProducts = products;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.error = 'Could not load products. Is the API running?';
      }
    });
  }
}
