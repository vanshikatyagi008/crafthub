import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { OrderService } from '../../services/order.service';
import { CreateOrderRequest } from '../../models/order.model';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent implements OnInit {
  model: CreateOrderRequest = {
    shippingAddress: '',
    shippingCity: '',
    shippingPostalCode: '',
    contactPhone: ''
  };

  placing = false;
  error = '';

  constructor(
    public cart: CartService,
    private orderService: OrderService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cart.loadCart().subscribe({ error: () => {} });
  }

  submit(): void {
    if (this.cart.items().length === 0) return;

    this.placing = true;
    this.error = '';

    this.orderService.placeOrder(this.model).subscribe({
      next: (order) => {
        this.cart.clearLocal();
        this.router.navigate(['/orders'], { queryParams: { placed: order.id } });
      },
      error: (err) => {
        this.placing = false;
        this.error = err?.error?.message || 'Could not place your order. Please try again.';
      }
    });
  }
}
