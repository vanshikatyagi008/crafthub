import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { CategoryService } from '../../services/category.service';
import { Product, ProductQueryParams } from '../../models/product.model';
import { Category } from '../../models/category.model';
import { ProductCardComponent } from '../product-card/product-card.component';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, FormsModule, ProductCardComponent],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  categories: Category[] = [];
  loading = true;
  error = '';

  query: ProductQueryParams = { page: 1, pageSize: 12, sortBy: 'newest' };
  totalPages = 1;
  totalCount = 0;

  constructor(
    private productService: ProductService,
    private categoryService: CategoryService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.categoryService.getAll().subscribe({ next: (c) => (this.categories = c) });

    this.route.queryParamMap.subscribe((params) => {
      this.query = {
        ...this.query,
        search: params.get('search') ?? undefined,
        categoryId: params.get('categoryId') ? Number(params.get('categoryId')) : undefined,
        page: params.get('page') ? Number(params.get('page')) : 1
      };
      this.fetchProducts();
    });
  }

  fetchProducts(): void {
    this.loading = true;
    this.productService.getAll(this.query).subscribe({
      next: (result) => {
        this.products = result.items;
        this.totalPages = result.totalPages;
        this.totalCount = result.totalCount;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.error = 'Could not load products. Is the API running?';
      }
    });
  }

  onFilterChange(): void {
    this.query.page = 1;
    this.fetchProducts();
  }

  onCategoryChange(categoryId: string): void {
    this.query.categoryId = categoryId ? Number(categoryId) : undefined;
    this.onFilterChange();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.query.page = page;
    this.fetchProducts();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
