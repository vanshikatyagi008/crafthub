import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})
export class ProductDetailComponent implements OnInit {
  product: Product | null = null;
  loading = true;
  error = '';
  quantity = 1;
  adding = false;
  addedMessage = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private cartService: CartService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    const idOrSlug = this.route.snapshot.paramMap.get('idOrSlug')!;
    this.productService.getOne(idOrSlug).subscribe({
      next: (p) => {
        this.product = p;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.error = 'Product not found.';
      }
    });
  }

  get discountPercent(): number | null {
    if (!this.product?.salePrice) return null;
    return Math.round(100 - (this.product.salePrice / this.product.price) * 100);
  }

  addToCart(): void {
    if (!this.product) return;

    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }

    this.adding = true;
    this.addedMessage = '';
    this.cartService.addToCart({ productId: this.product.id, quantity: this.quantity }).subscribe({
      next: () => {
        this.adding = false;
        this.addedMessage = `${this.quantity} × ${this.product!.name} added to your cart.`;
      },
      error: () => (this.adding = false)
    });
  }
}
