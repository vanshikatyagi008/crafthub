import { HttpClient } from '@angular/common/http';
import { Injectable, computed, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AddToCartRequest, CartItem } from '../models/cart-item.model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly apiUrl = `${environment.apiUrl}/cart`;

  items = signal<CartItem[]>([]);
  itemCount = computed(() => this.items().reduce((sum, i) => sum + i.quantity, 0));
  subtotal = computed(() => this.items().reduce((sum, i) => sum + i.lineTotal, 0));

  constructor(private http: HttpClient) {}

  loadCart(): Observable<CartItem[]> {
    return this.http.get<CartItem[]>(this.apiUrl).pipe(
      tap((items) => this.items.set(items))
    );
  }

  addToCart(payload: AddToCartRequest): Observable<unknown> {
    return this.http.post(this.apiUrl, payload).pipe(
      tap(() => this.loadCart().subscribe())
    );
  }

  updateQuantity(cartItemId: number, quantity: number): Observable<unknown> {
    return this.http.put(`${this.apiUrl}/${cartItemId}`, { quantity }).pipe(
      tap(() => this.loadCart().subscribe())
    );
  }

  removeItem(cartItemId: number): Observable<unknown> {
    return this.http.delete(`${this.apiUrl}/${cartItemId}`).pipe(
      tap(() => this.loadCart().subscribe())
    );
  }

  clearCart(): Observable<unknown> {
    return this.http.delete(this.apiUrl).pipe(
      tap(() => this.items.set([]))
    );
  }

  clearLocal(): void {
    this.items.set([]);
  }
}
