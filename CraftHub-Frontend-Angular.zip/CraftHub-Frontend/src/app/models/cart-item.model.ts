export interface CartItem {
  id: number;
  productId: number;
  productName: string;
  imageUrl: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
  availableStock: number;
}

export interface AddToCartRequest {
  productId: number;
  quantity: number;
}
