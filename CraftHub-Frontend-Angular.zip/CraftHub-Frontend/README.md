# CraftHub Frontend (Angular 18, standalone components)

An art & craft e-commerce storefront, inspired by the category structure of
itsybitsy.in — built to talk to the CraftHub .NET API (EF Core + JWT).

## Stack
- Angular 18 (standalone components, no NgModules)
- Signals for reactive cart/auth state
- Functional route guard + HTTP interceptor for JWT
- Plain CSS with a shared design-token stylesheet (`src/styles.css`)

## Project layout
```
src/app/
  models/            TypeScript interfaces mirroring the API DTOs
  services/           auth, category, product, cart, order services (HttpClient)
  guards/             authGuard (must be logged in), adminGuard (Admin role)
  interceptors/        authInterceptor (attaches JWT Bearer token)
  components/
    navbar/  footer/                shared layout
    home/                            hero + categories + featured products
    product-list/  product-card/    catalog with search/filter/sort + pagination
    product-detail/                 single product page, add-to-cart
    cart/                           cart view, quantity edit, remove
    login/  register/                auth forms
    checkout/                       shipping form + order summary -> places order
    order-history/                  past orders for the signed-in user
    not-found/                      404 page
  app.routes.ts, app.config.ts, app.component.*
```

## 1. Point the frontend at your API
Edit `src/environments/environment.ts`:
```ts
export const environment = {
  production: false,
  apiUrl: 'https://localhost:7168/api'   // <-- your CraftHub.API URL
};
```
Match this to whatever port `dotnet run` prints for the backend (check the
`launchSettings.json` / console output — Kestrel usually picks 5xxx/7xxx).

## 2. Install & run
```bash
npm install
npm start
```
Opens on `http://localhost:4200`. Make sure the backend's CORS
`AllowedOrigins` (in `appsettings.json`) includes this URL — it does by default.

## 3. How auth works
- `AuthService` stores the JWT + user info in `localStorage` and exposes a
  `signal<AuthUser | null>` so the navbar/guards update instantly on login/logout.
- `authInterceptor` attaches `Authorization: Bearer <token>` to every request.
- `authGuard` protects `/checkout` and `/orders`; `adminGuard` is ready to use
  on any future `/admin` routes.

## 4. Talking to the backend
All calls go through small, focused services (`ProductService`, `CartService`,
etc.) using Angular's `HttpClient` — no extra state library needed since the
app is small enough for signals + services.

## Notes on images
Product/category photos currently point at `picsum.photos/seed/...` placeholders
so the store isn't empty out of the box. Swap `ImageUrl` values in the
backend's `DbSeeder.cs` (or your database once connected) for real product photography.
