using CraftHub.API.Models;

namespace CraftHub.API.Services
{
    public interface ITokenService
    {
        string CreateToken(ApplicationUser user, out DateTime expiresAt);
    }
}
