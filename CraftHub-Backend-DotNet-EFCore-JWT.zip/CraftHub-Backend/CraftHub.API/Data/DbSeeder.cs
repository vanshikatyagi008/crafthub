using CraftHub.API.Models;

namespace CraftHub.API.Data
{
    public static class DbSeeder
    {
        public static void Seed(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (!context.Categories.Any())
            {
                var categories = new List<Category>
                {
                    new() { Name = "Art Supplies", Slug = "art-supplies", Description = "Paints, canvases, brushes and more for every artist.", ImageUrl = "https://picsum.photos/seed/art-supplies/600/600" },
                    new() { Name = "Resin Art", Slug = "resin-art", Description = "Epoxy resin, moulds and pigments for stunning resin creations.", ImageUrl = "https://picsum.photos/seed/resin-art/600/600" },
                    new() { Name = "Paper Crafting", Slug = "paper-crafting", Description = "Paper packs, stencils, stickers and cutting machines.", ImageUrl = "https://picsum.photos/seed/paper-crafting/600/600" },
                    new() { Name = "DIY Kits", Slug = "diy-kits", Description = "Ready-to-make kits for all ages and skill levels.", ImageUrl = "https://picsum.photos/seed/diy-kits/600/600" },
                    new() { Name = "Kids Range", Slug = "kids-range", Description = "Safe, fun craft supplies made for little hands.", ImageUrl = "https://picsum.photos/seed/kids-range/600/600" },
                    new() { Name = "Jewellery Making", Slug = "jewellery-making", Description = "Beads, findings and tools to design your own jewellery.", ImageUrl = "https://picsum.photos/seed/jewellery-making/600/600" },
                    new() { Name = "Home Decor", Slug = "home-decor", Description = "Wall art, frames and decor pieces to craft and display.", ImageUrl = "https://picsum.photos/seed/home-decor/600/600" },
                    new() { Name = "Stationery", Slug = "stationery", Description = "Journals, notebooks and everyday essentials.", ImageUrl = "https://picsum.photos/seed/stationery/600/600" },
                };
                context.Categories.AddRange(categories);
                context.SaveChanges();
            }

            if (!context.Products.Any())
            {
                var art = context.Categories.First(c => c.Slug == "art-supplies").Id;
                var resin = context.Categories.First(c => c.Slug == "resin-art").Id;
                var paper = context.Categories.First(c => c.Slug == "paper-crafting").Id;
                var diy = context.Categories.First(c => c.Slug == "diy-kits").Id;
                var kids = context.Categories.First(c => c.Slug == "kids-range").Id;
                var jewellery = context.Categories.First(c => c.Slug == "jewellery-making").Id;
                var decor = context.Categories.First(c => c.Slug == "home-decor").Id;
                var stationery = context.Categories.First(c => c.Slug == "stationery").Id;

                var products = new List<Product>
                {
                    new() { Name = "Multi Style Acrylics Set - 52 Colours", Slug = "multi-style-acrylics-52", Description = "A vibrant 52-colour acrylic paint set, 15ml each, perfect for canvas, wood and mixed media art.", Price = 1999.00m, SalePrice = 1399.30m, StockQuantity = 40, ImageUrl = "https://picsum.photos/seed/acrylics-52/600/600", Rating = 4.6, ReviewCount = 4, IsFeatured = true, CategoryId = art },
                    new() { Name = "Artist Canvas Board 12x16 inch", Slug = "canvas-board-12x16", Description = "Primed cotton canvas board, ideal for acrylics and oils.", Price = 349.00m, StockQuantity = 60, ImageUrl = "https://picsum.photos/seed/canvas-board/600/600", Rating = 4.4, ReviewCount = 21, IsFeatured = false, CategoryId = art },
                    new() { Name = "Decor Varnish Gloss 100ml", Slug = "decor-varnish-gloss-100ml", Description = "High-gloss protective varnish for finished art and craft projects.", Price = 250.00m, StockQuantity = 100, ImageUrl = "https://picsum.photos/seed/varnish-gloss/600/600", Rating = 4.7, ReviewCount = 75, IsFeatured = true, CategoryId = art },
                    new() { Name = "Fine Detail Paint Brush Set (12pc)", Slug = "paint-brush-set-12pc", Description = "A precision brush set for detailing, line work and fine art.", Price = 299.00m, SalePrice = 239.20m, StockQuantity = 55, ImageUrl = "https://picsum.photos/seed/brush-set/600/600", Rating = 4.5, ReviewCount = 18, CategoryId = art },

                    new() { Name = "Epoxy Art Resin & Hardener 750gm", Slug = "epoxy-resin-750gm", Description = "Crystal-clear epoxy resin and hardener for coasters, jewellery and art.", Price = 1299.00m, SalePrice = 1039.20m, StockQuantity = 30, ImageUrl = "https://picsum.photos/seed/epoxy-resin/600/600", Rating = 4.6, ReviewCount = 14, IsFeatured = true, CategoryId = resin },
                    new() { Name = "Silicone Resin Coaster Moulds (Set of 4)", Slug = "resin-coaster-moulds", Description = "Round and hexagon silicone moulds for resin coasters.", Price = 399.00m, StockQuantity = 45, ImageUrl = "https://picsum.photos/seed/resin-moulds/600/600", Rating = 4.3, ReviewCount = 9, CategoryId = resin },
                    new() { Name = "Alcohol Ink Set - 12 Vibrant Shades", Slug = "alcohol-ink-set-12", Description = "Highly pigmented alcohol inks for resin and pouring art.", Price = 599.00m, SalePrice = 479.20m, StockQuantity = 25, ImageUrl = "https://picsum.photos/seed/alcohol-ink/600/600", Rating = 4.5, ReviewCount = 7, CategoryId = resin },

                    new() { Name = "Decoupage Paper Pack - Starlight Voyage", Slug = "decoupage-paper-starlight", Description = "Premium 60GSM A4 decoupage sheets, 2 designs.", Price = 169.00m, SalePrice = 135.20m, StockQuantity = 70, ImageUrl = "https://picsum.photos/seed/decoupage-paper/600/600", Rating = 4.4, ReviewCount = 5, CategoryId = paper },
                    new() { Name = "Dream Cut Machine - Die Cutting Tool", Slug = "dream-cut-machine", Description = "Manual die-cutting and embossing machine for card making.", Price = 2499.00m, StockQuantity = 15, ImageUrl = "https://picsum.photos/seed/cut-machine/600/600", Rating = 4.7, ReviewCount = 22, IsFeatured = true, CategoryId = paper },
                    new() { Name = "Washi Tape Set - 10 Rolls", Slug = "washi-tape-set-10", Description = "Decorative washi tape rolls for journaling and scrapbooking.", Price = 249.00m, StockQuantity = 90, ImageUrl = "https://picsum.photos/seed/washi-tape/600/600", Rating = 4.6, ReviewCount = 31, CategoryId = paper },

                    new() { Name = "DIY Build-a-Mini-Cottage Kit", Slug = "diy-mini-cottage-kit", Description = "A complete miniature house making kit for kids & adults.", Price = 699.00m, SalePrice = 559.20m, StockQuantity = 35, ImageUrl = "https://picsum.photos/seed/mini-cottage/600/600", Rating = 4.8, ReviewCount = 46, IsFeatured = true, CategoryId = diy },
                    new() { Name = "Paint by Numbers - Town Walk", Slug = "paint-by-numbers-town-walk", Description = "Canvas kit with easel and acrylic paints for guided painting.", Price = 499.00m, SalePrice = 399.20m, StockQuantity = 50, ImageUrl = "https://picsum.photos/seed/paint-by-numbers/600/600", Rating = 4.5, ReviewCount = 8, CategoryId = diy },
                    new() { Name = "DIY Amigurumi Crochet Kit - Unicorn", Slug = "diy-amigurumi-unicorn", Description = "Beginner-friendly crochet kit with yarn, hook and instructions.", Price = 899.00m, SalePrice = 719.20m, StockQuantity = 20, ImageUrl = "https://picsum.photos/seed/amigurumi-unicorn/600/600", Rating = 4.6, ReviewCount = 3, CategoryId = diy },

                    new() { Name = "Fun Finger Paint Set for Kids", Slug = "finger-paint-kids", Description = "Non-toxic, washable finger paints in 6 bright colours.", Price = 249.00m, StockQuantity = 80, ImageUrl = "https://picsum.photos/seed/finger-paint/600/600", Rating = 4.7, ReviewCount = 27, CategoryId = kids },
                    new() { Name = "Colour Me Fairyland Pre-Cut Shapes", Slug = "fairyland-precut-shapes", Description = "Pre-cut craft shapes for imaginative colouring and pasting.", Price = 199.00m, StockQuantity = 65, ImageUrl = "https://picsum.photos/seed/fairyland/600/600", Rating = 4.8, ReviewCount = 12, IsFeatured = true, CategoryId = kids },
                    new() { Name = "Googly Eyes Assorted Pack (100pc)", Slug = "googly-eyes-100pc", Description = "Assorted size googly eyes for craft projects and toys.", Price = 99.00m, StockQuantity = 150, ImageUrl = "https://picsum.photos/seed/googly-eyes/600/600", Rating = 4.5, ReviewCount = 19, CategoryId = kids },

                    new() { Name = "Jewellery Findings Assorted - Gold", Slug = "jewellery-findings-gold", Description = "Assorted gold-tone jewellery findings for handmade designs.", Price = 149.00m, SalePrice = 119.20m, StockQuantity = 60, ImageUrl = "https://picsum.photos/seed/jewellery-gold/600/600", Rating = 4.3, ReviewCount = 6, CategoryId = jewellery },
                    new() { Name = "Seed Beads & Cord Set - Rosy Hues", Slug = "seed-beads-rosy-hues", Description = "Seed beads, findings and cord in soft rose tones.", Price = 99.00m, SalePrice = 69.30m, StockQuantity = 75, ImageUrl = "https://picsum.photos/seed/seed-beads/600/600", Rating = 4.4, ReviewCount = 4, CategoryId = jewellery },

                    new() { Name = "MDF Wall Clock Blank - Round 10in", Slug = "mdf-wall-clock-blank", Description = "Unfinished MDF clock base ready for painting and decoupage.", Price = 299.00m, StockQuantity = 40, ImageUrl = "https://picsum.photos/seed/mdf-clock/600/600", Rating = 4.5, ReviewCount = 11, CategoryId = decor },
                    new() { Name = "Artificial Flower Bunch - Pastel Peony", Slug = "artificial-flower-peony", Description = "Realistic pastel peony bunch for home decor and gifting.", Price = 199.00m, StockQuantity = 55, ImageUrl = "https://picsum.photos/seed/peony-flowers/600/600", Rating = 4.6, ReviewCount = 8, CategoryId = decor },

                    new() { Name = "Kraft Journal Notebook - A5", Slug = "kraft-journal-a5", Description = "Rustic kraft cover journal with 200 dotted pages.", Price = 249.00m, StockQuantity = 90, ImageUrl = "https://picsum.photos/seed/kraft-journal/600/600", Rating = 4.7, ReviewCount = 33, IsFeatured = true, CategoryId = stationery },
                    new() { Name = "Adult Colouring Book - Mandala Bliss", Slug = "colouring-book-mandala", Description = "Intricate mandala designs for relaxing colouring sessions.", Price = 199.00m, StockQuantity = 70, ImageUrl = "https://picsum.photos/seed/mandala-book/600/600", Rating = 4.6, ReviewCount = 15, CategoryId = stationery },
                };

                context.Products.AddRange(products);
                context.SaveChanges();
            }
        }
    }
}
