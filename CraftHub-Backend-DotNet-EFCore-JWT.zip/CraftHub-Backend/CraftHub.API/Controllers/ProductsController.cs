using CraftHub.API.Data;
using CraftHub.API.DTOs;
using CraftHub.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CraftHub.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult> GetAll([FromQuery] ProductQueryParams query)
        {
            var products = _context.Products.Include(p => p.Category)
                .Where(p => p.IsActive)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(query.Search))
                products = products.Where(p => p.Name.Contains(query.Search) || (p.Description != null && p.Description.Contains(query.Search)));

            if (query.CategoryId.HasValue)
                products = products.Where(p => p.CategoryId == query.CategoryId.Value);

            if (query.MinPrice.HasValue)
                products = products.Where(p => (p.SalePrice ?? p.Price) >= query.MinPrice.Value);

            if (query.MaxPrice.HasValue)
                products = products.Where(p => (p.SalePrice ?? p.Price) <= query.MaxPrice.Value);

            products = query.SortBy switch
            {
                "price_asc" => products.OrderBy(p => p.SalePrice ?? p.Price),
                "price_desc" => products.OrderByDescending(p => p.SalePrice ?? p.Price),
                "rating" => products.OrderByDescending(p => p.Rating),
                _ => products.OrderByDescending(p => p.CreatedAt)
            };

            var totalCount = await products.CountAsync();

            var items = await products
                .Skip((query.Page - 1) * query.PageSize)
                .Take(query.PageSize)
                .Select(p => new ProductDto
                {
                    Id = p.Id,
                    Name = p.Name,
                    Slug = p.Slug,
                    Description = p.Description,
                    Price = p.Price,
                    SalePrice = p.SalePrice,
                    StockQuantity = p.StockQuantity,
                    ImageUrl = p.ImageUrl,
                    Rating = p.Rating,
                    ReviewCount = p.ReviewCount,
                    IsFeatured = p.IsFeatured,
                    CategoryId = p.CategoryId,
                    CategoryName = p.Category!.Name
                })
                .ToListAsync();

            return Ok(new
            {
                items,
                totalCount,
                page = query.Page,
                pageSize = query.PageSize,
                totalPages = (int)Math.Ceiling(totalCount / (double)query.PageSize)
            });
        }

        [HttpGet("featured")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetFeatured()
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.IsActive && p.IsFeatured)
                .Select(p => new ProductDto
                {
                    Id = p.Id,
                    Name = p.Name,
                    Slug = p.Slug,
                    Description = p.Description,
                    Price = p.Price,
                    SalePrice = p.SalePrice,
                    StockQuantity = p.StockQuantity,
                    ImageUrl = p.ImageUrl,
                    Rating = p.Rating,
                    ReviewCount = p.ReviewCount,
                    IsFeatured = p.IsFeatured,
                    CategoryId = p.CategoryId,
                    CategoryName = p.Category!.Name
                })
                .ToListAsync();

            return Ok(products);
        }

        [HttpGet("{idOrSlug}")]
        public async Task<ActionResult<ProductDto>> Get(string idOrSlug)
        {
            var query = _context.Products.Include(p => p.Category).AsQueryable();

            var product = int.TryParse(idOrSlug, out var id)
                ? await query.FirstOrDefaultAsync(p => p.Id == id)
                : await query.FirstOrDefaultAsync(p => p.Slug == idOrSlug);

            if (product is null) return NotFound();

            return Ok(new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Slug = product.Slug,
                Description = product.Description,
                Price = product.Price,
                SalePrice = product.SalePrice,
                StockQuantity = product.StockQuantity,
                ImageUrl = product.ImageUrl,
                Rating = product.Rating,
                ReviewCount = product.ReviewCount,
                IsFeatured = product.IsFeatured,
                CategoryId = product.CategoryId,
                CategoryName = product.Category!.Name
            });
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<ActionResult<ProductDto>> Create(ProductCreateDto dto)
        {
            var product = new Product
            {
                Name = dto.Name,
                Slug = dto.Slug,
                Description = dto.Description,
                Price = dto.Price,
                SalePrice = dto.SalePrice,
                StockQuantity = dto.StockQuantity,
                ImageUrl = dto.ImageUrl,
                Sku = dto.Sku,
                IsFeatured = dto.IsFeatured,
                CategoryId = dto.CategoryId
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { idOrSlug = product.Id.ToString() }, product);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, ProductCreateDto dto)
        {
            var product = await _context.Products.FindAsync(id);
            if (product is null) return NotFound();

            product.Name = dto.Name;
            product.Slug = dto.Slug;
            product.Description = dto.Description;
            product.Price = dto.Price;
            product.SalePrice = dto.SalePrice;
            product.StockQuantity = dto.StockQuantity;
            product.ImageUrl = dto.ImageUrl;
            product.Sku = dto.Sku;
            product.IsFeatured = dto.IsFeatured;
            product.CategoryId = dto.CategoryId;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product is null) return NotFound();

            product.IsActive = false; // soft delete
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
