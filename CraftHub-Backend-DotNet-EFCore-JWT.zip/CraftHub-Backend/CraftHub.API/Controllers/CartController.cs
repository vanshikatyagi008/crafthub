using System.Security.Claims;
using CraftHub.API.Data;
using CraftHub.API.DTOs;
using CraftHub.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CraftHub.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CartController(ApplicationDbContext context)
        {
            _context = context;
        }

        private int CurrentUserId =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("sub")!.Value);

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CartItemDto>>> GetCart()
        {
            var items = await _context.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.UserId == CurrentUserId)
                .Select(ci => new CartItemDto
                {
                    Id = ci.Id,
                    ProductId = ci.ProductId,
                    ProductName = ci.Product!.Name,
                    ImageUrl = ci.Product.ImageUrl,
                    UnitPrice = ci.Product.SalePrice ?? ci.Product.Price,
                    Quantity = ci.Quantity,
                    LineTotal = (ci.Product.SalePrice ?? ci.Product.Price) * ci.Quantity,
                    AvailableStock = ci.Product.StockQuantity
                })
                .ToListAsync();

            return Ok(items);
        }

        [HttpPost]
        public async Task<ActionResult> AddToCart(AddToCartDto dto)
        {
            var product = await _context.Products.FindAsync(dto.ProductId);
            if (product is null || !product.IsActive) return NotFound(new { message = "Product not found." });

            if (dto.Quantity < 1) dto.Quantity = 1;

            var existing = await _context.CartItems
                .FirstOrDefaultAsync(ci => ci.UserId == CurrentUserId && ci.ProductId == dto.ProductId);

            if (existing is not null)
            {
                existing.Quantity += dto.Quantity;
            }
            else
            {
                _context.CartItems.Add(new CartItem
                {
                    UserId = CurrentUserId,
                    ProductId = dto.ProductId,
                    Quantity = dto.Quantity
                });
            }

            await _context.SaveChangesAsync();
            return Ok(new { message = "Added to cart." });
        }

        [HttpPut("{cartItemId:int}")]
        public async Task<IActionResult> UpdateQuantity(int cartItemId, UpdateCartItemDto dto)
        {
            var item = await _context.CartItems
                .FirstOrDefaultAsync(ci => ci.Id == cartItemId && ci.UserId == CurrentUserId);

            if (item is null) return NotFound();

            if (dto.Quantity < 1)
            {
                _context.CartItems.Remove(item);
            }
            else
            {
                item.Quantity = dto.Quantity;
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{cartItemId:int}")]
        public async Task<IActionResult> RemoveItem(int cartItemId)
        {
            var item = await _context.CartItems
                .FirstOrDefaultAsync(ci => ci.Id == cartItemId && ci.UserId == CurrentUserId);

            if (item is null) return NotFound();

            _context.CartItems.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete]
        public async Task<IActionResult> ClearCart()
        {
            var items = _context.CartItems.Where(ci => ci.UserId == CurrentUserId);
            _context.CartItems.RemoveRange(items);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
