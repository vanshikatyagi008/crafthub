using System.Security.Claims;
using CraftHub.API.Data;
using CraftHub.API.DTOs;
using CraftHub.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CraftHub.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public OrdersController(ApplicationDbContext context)
        {
            _context = context;
        }

        private int CurrentUserId =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("sub")!.Value);

        private bool IsAdmin => User.IsInRole("Admin");

        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderDto>>> GetMyOrders()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                .Where(o => o.UserId == CurrentUserId)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return Ok(orders.Select(MapToDto));
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("all")]
        public async Task<ActionResult<IEnumerable<OrderDto>>> GetAllOrders()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return Ok(orders.Select(MapToDto));
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<OrderDto>> GetOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.Id == id && (o.UserId == CurrentUserId || IsAdmin));

            if (order is null) return NotFound();

            return Ok(MapToDto(order));
        }

        [HttpPost]
        public async Task<ActionResult<OrderDto>> PlaceOrder(CreateOrderDto dto)
        {
            var cartItems = await _context.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.UserId == CurrentUserId)
                .ToListAsync();

            if (!cartItems.Any())
                return BadRequest(new { message = "Your cart is empty." });

            foreach (var ci in cartItems)
            {
                if (ci.Product!.StockQuantity < ci.Quantity)
                    return BadRequest(new { message = $"Not enough stock for '{ci.Product.Name}'." });
            }

            var order = new Order
            {
                UserId = CurrentUserId,
                ShippingAddress = dto.ShippingAddress,
                ShippingCity = dto.ShippingCity,
                ShippingPostalCode = dto.ShippingPostalCode,
                ContactPhone = dto.ContactPhone,
                Status = OrderStatus.Pending
            };

            decimal total = 0;
            foreach (var ci in cartItems)
            {
                var unitPrice = ci.Product!.SalePrice ?? ci.Product.Price;
                var lineTotal = unitPrice * ci.Quantity;
                total += lineTotal;

                order.OrderItems.Add(new OrderItem
                {
                    ProductId = ci.ProductId,
                    ProductName = ci.Product.Name,
                    UnitPrice = unitPrice,
                    Quantity = ci.Quantity
                });

                ci.Product.StockQuantity -= ci.Quantity;
            }

            order.TotalAmount = total;

            _context.Orders.Add(order);
            _context.CartItems.RemoveRange(cartItems);

            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrder), new { id = order.Id }, MapToDto(order));
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id:int}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] OrderStatus status)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order is null) return NotFound();

            order.Status = status;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private static OrderDto MapToDto(Order order) => new()
        {
            Id = order.Id,
            ShippingAddress = order.ShippingAddress,
            ShippingCity = order.ShippingCity,
            ShippingPostalCode = order.ShippingPostalCode,
            ContactPhone = order.ContactPhone,
            TotalAmount = order.TotalAmount,
            Status = order.Status.ToString(),
            CreatedAt = order.CreatedAt,
            Items = order.OrderItems.Select(oi => new OrderItemDto
            {
                ProductId = oi.ProductId,
                ProductName = oi.ProductName,
                UnitPrice = oi.UnitPrice,
                Quantity = oi.Quantity,
                LineTotal = oi.UnitPrice * oi.Quantity
            }).ToList()
        };
    }
}
