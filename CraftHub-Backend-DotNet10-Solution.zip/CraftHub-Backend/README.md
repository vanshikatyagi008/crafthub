# CraftHub API (.NET 10 + EF Core + JWT)

## Opening & running in Visual Studio
1. Double-click **`CraftHub.slnx`** — this is the new XML solution format; Visual Studio
   2022 (17.13+) and later open it directly, same as a `.sln`.
2. Make sure the **CraftHub.API** project is set as the Startup Project (it's the only
   one, so this should already be the case — right-click it → "Set as Startup Project"
   if not).
3. Pick a launch profile from the toolbar dropdown next to the green Run button:
   `https` (recommended, matches the Angular app's `environment.ts`), `http`, or
   `IIS Express`. Press **F5** / the Run button.
4. Visual Studio will build, launch Kestrel, and open Swagger at `/swagger` automatically
   (`launchUrl` is preset in `Properties/launchSettings.json`).

If you see a certificate warning on `https://localhost:7168`, run this once from a
terminal to trust the local dev cert: `dotnet dev-certs https --trust`.

## Running from the command line instead
```bash
cd CraftHub.API
dotnet restore
dotnet run --launch-profile https
```


Backend for an art & craft e-commerce site, inspired by the category structure of
itsybitsy.in (Art Supplies, Resin Art, Paper Crafting, DIY Kits, Kids Range, Jewellery
Making, Home Decor, Stationery).

## Stack
- ASP.NET Core 8 Web API
- Entity Framework Core 8 (SQL Server)
- JWT Bearer authentication (custom, BCrypt password hashing)
- CORS configured for an Angular dev server on `http://localhost:4200`
- Swagger / OpenAPI

## Project layout
```
CraftHub.API/
  Controllers/      AuthController, CategoriesController, ProductsController,
                     CartController, OrdersController
  Data/              ApplicationDbContext, DbSeeder
  Models/            ApplicationUser, Category, Product, CartItem, Order, OrderItem
  DTOs/              Request/response shapes (Auth/, CategoryDto, ProductDto, ...)
  Services/          ITokenService / TokenService (JWT issuing)
  Helpers/           JwtSettings
  Program.cs         DI, EF Core, JWT, CORS, Swagger wiring
  appsettings.json   Connection string + JWT secret (CHANGE the secret!)
```

## 1. Connect your database
Edit `appsettings.json` -> `ConnectionStrings:DefaultConnection`. Defaults to LocalDB:
```
Server=(localdb)\mssqllocaldb;Database=CraftHubDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True
```
For a full SQL Server / Azure SQL instance, swap in your own connection string.

## 2. Restore & run
```bash
cd CraftHub.API
dotnet restore
dotnet run
```
On first run, `DbSeeder.Seed()` calls `EnsureCreated()`, creates the schema, and
inserts 8 categories and ~20 sample products with placeholder images so the site
isn't empty while you connect your own data.

### Switching to real EF Core migrations (recommended before production)
```bash
dotnet tool install --global dotnet-ef   # once
dotnet ef migrations add InitialCreate
dotnet ef database update
```
Then in `Program.cs` replace `DbSeeder.Seed(db)`'s `EnsureCreated()` call with
`db.Database.Migrate()` so schema changes are tracked going forward.

## 3. JWT settings
In `appsettings.json`:
```json
"JwtSettings": {
  "Secret": "CHANGE_ME_TO_A_LONG_RANDOM_SECRET",
  "Issuer": "CraftHubAPI",
  "Audience": "CraftHubClient",
  "ExpiryMinutes": 120
}
```
`Secret` must be at least 32 characters. Never commit a real secret to source control —
use `dotnet user-secrets` or environment variables in production.

## 4. Endpoints

| Method | Route                          | Auth        | Description               |
|--------|--------------------------------|-------------|---------------------------|
| POST   | /api/auth/register             | -           | Create account, returns JWT |
| POST   | /api/auth/login                | -           | Login, returns JWT        |
| GET    | /api/auth/me                   | JWT         | Current user profile      |
| GET    | /api/categories                | -           | List categories           |
| GET    | /api/categories/{idOrSlug}     | -           | Category detail           |
| POST/PUT/DELETE /api/categories| Admin role  | Manage categories         |
| GET    | /api/products?search=&categoryId=&sortBy=&page=&pageSize= | - | Paged product list |
| GET    | /api/products/featured         | -           | Featured products         |
| GET    | /api/products/{idOrSlug}       | -           | Product detail             |
| POST/PUT/DELETE /api/products  | Admin role  | Manage products (soft delete) |
| GET    | /api/cart                      | JWT         | Current user's cart        |
| POST   | /api/cart                      | JWT         | Add item to cart           |
| PUT    | /api/cart/{cartItemId}         | JWT         | Update quantity             |
| DELETE | /api/cart/{cartItemId}         | JWT         | Remove item                 |
| DELETE | /api/cart                      | JWT         | Clear cart                  |
| GET    | /api/orders                    | JWT         | My orders                   |
| GET    | /api/orders/all                | Admin role  | All orders                  |
| GET    | /api/orders/{id}                | JWT         | Order detail                |
| POST   | /api/orders                    | JWT         | Place order from cart       |
| PUT    | /api/orders/{id}/status         | Admin role  | Update order status         |

Swagger UI is available at `/swagger` in development, with a "Bearer {token}"
auth box so you can test protected endpoints directly.

## Making the first Admin user
There's no seeded admin. Register normally via `/api/auth/register`, then
manually flip that user's `Role` column from `Customer` to `Admin` in the
database (or add a temporary endpoint) the first time.
